# Requirements Cluster Labeling Using LLMs
## Extending: "Enhancing Software Requirements Cluster Labeling Using Wikipedia" (Reddivari et al.)

---

## Project Goal

Replicate the paper's clustering + labeling pipeline, replace Wikipedia-based
labeling with **LLM-based labeling** (LLaMA 3.2 and Mistral via Ollama), and
compare results against the paper's Table V Kappa scores.

---

## Quick Start

### 1. Install dependencies
```bash
pip install -r requirements.txt
python -c "import nltk; nltk.download('stopwords'); nltk.download('punkt')"
```

### 2. Place dataset files
```
data/raw/itrust/   ← paste iTrust use case .txt files here
data/raw/etour/    ← paste eTour use case .txt files (English translations)
data/raw/cm1/      ← paste CM-1 requirement .txt files here
```
Also copy each dataset's `ground.txt` into the same folder.

### 3. Make sure Ollama is running
```bash
ollama serve                  # start Ollama server
ollama pull llama3.2          # pull LLaMA model
ollama pull mistral           # pull Mistral model
```

### 4. Run the pipeline
```bash
# Full run (all datasets, all methods including LLMs)
python main.py

# Single dataset
python main.py --dataset itrust

# Skip LLM (fast test of traditional methods only)
python main.py --no-llm

# Single dataset, no LLM
python main.py --dataset itrust --no-llm
```

---

## Kappa Evaluation Switch

In `config.py`:
```python
USE_KAPPA = 0   # 0 = skip Kappa (no gold standard needed)
USE_KAPPA = 1   # 1 = run Kappa (requires gold standard JSON files)
```

When you have expert labels, create files in `data/gold_standard/`.
See `data/gold_standard/TEMPLATE.md` for instructions.

---

## Project Structure

```
requirements_cluster_labeling/
│
├── config.py                        ← ALL settings live here
├── main.py                          ← Master pipeline runner
├── requirements.txt
│
├── data/
│   ├── raw/                         ← Put dataset .txt files here
│   │   ├── itrust/
│   │   ├── etour/
│   │   └── cm1/
│   ├── processed/                   ← Auto-generated preprocessed cache
│   └── gold_standard/               ← Expert labels for Kappa (optional)
│       └── TEMPLATE.md
│
├── preprocessing/
│   └── preprocess.py                ← Tokenize, stop words, Porter stemming
│
├── clustering/
│   └── cluster.py                   ← Single-link agglomerative clustering
│
├── labeling/
│   ├── traditional/
│   │   ├── tf_labeler.py            ← Term Frequency labels
│   │   ├── chi2_labeler.py          ← Chi-squared labels
│   │   └── fpw_labeler.py           ← Frequent and Predictive Words labels
│   └── llm/
│       ├── ollama_client.py         ← Ollama wrapper (swap for GPT-4 here later)
│       ├── strategy_a.py            ← Full text → LLM → labels
│       └── strategy_b.py            ← TF-IDF keywords → LLM → labels
│
├── evaluation/
│   ├── kappa.py                     ← Cohen's Kappa (USE_KAPPA switch)
│   └── nmi_ari.py                   ← NMI + ARI (always runs)
│
└── results/
    ├── tables/                      ← CSV + JSON output files
    └── logs/                        ← Run logs
```

---

## Results Table (your contribution vs. paper)

| Dataset | TF   | χ²   | FPW  | WBL (paper) | LLaMA-A | LLaMA-B | Mistral-A | Mistral-B |
|---------|------|------|------|-------------|---------|---------|-----------|-----------|
| iTrust  | .42  | .79  | .62  | **.85**     | ?       | ?       | ?         | ?         |
| eTour   | .57  | .72  | .74  | **.79**     | ?       | ?       | ?         | ?         |
| CM-1    | .35  | .81  | .59  | **.87**     | ?       | ?       | ?         | ?         |

*TF/χ²/FPW/WBL values from paper Table V. Your LLM columns fill the ?s.*

---

## Switching to GPT-4 Later

Only one file needs to change: `labeling/llm/ollama_client.py`
Add a branch for `"gpt-4"` model name that calls the OpenAI API instead.
Everything else — strategies, evaluation, main.py — stays identical.
