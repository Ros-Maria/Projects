# =============================================================================
# preprocessing/preprocess.py
# Tokenize : remove stop words : Porter stem, matching the paper's pipeline.
# =============================================================================

import os
import re
import json
import logging
from nltk.corpus import stopwords
from nltk.stem import PorterStemmer
import nltk

# Download NLTK data if not already present
for pkg in ["stopwords", "punkt", "punkt_tab"]:
    try:
        nltk.data.find(f"tokenizers/{pkg}" if "punkt" in pkg else f"corpora/{pkg}")
    except LookupError:
        nltk.download(pkg, quiet=True)

import sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from config import DATA_PROCESSED, STOPWORDS_EXTRA

logger = logging.getLogger(__name__)


def load_requirements(dataset_path: str) -> dict[str, str]:
    """
    Load all .txt requirement files from a dataset folder.
    Returns: { filename: raw_text }
    """
    requirements = {}
    if not os.path.exists(dataset_path):
        raise FileNotFoundError(f"Dataset path not found: {dataset_path}")

    for fname in sorted(os.listdir(dataset_path)):
        if fname.lower().endswith(".txt"):
            fpath = os.path.join(dataset_path, fname)
            try:
                with open(fpath, "r", encoding="utf-8", errors="replace") as f:
                    text = f.read().strip()
                if text:
                    requirements[fname] = text
            except Exception as e:
                logger.warning(f"Could not read {fpath}: {e}")

    logger.info(f"Loaded {len(requirements)} requirements from {dataset_path}")
    return requirements


def preprocess_text(text: str, extra_stopwords: list[str] = None) -> list[str]:
    """
    Full preprocessing pipeline matching the paper:
      1. Lowercase
      2. Tokenize (alphanumeric only)
      3. Remove stop words (NLTK English + extra domain stop words)
      4. Porter stemming

    Returns list of stemmed tokens.
    """
    stemmer   = PorterStemmer()
    stop_set  = set(stopwords.words("english"))
    if extra_stopwords:
        stop_set.update([w.lower() for w in extra_stopwords])

    # 1. Lowercase
    text = text.lower()

    # 2. Tokenize — keep only alphabetic tokens (removes numbers/punctuation)
    tokens = re.findall(r"[a-z]+", text)

    # 3. Remove stop words (min length 2)
    tokens = [t for t in tokens if t not in stop_set and len(t) > 2]

    # 4. Porter stemming
    tokens = [stemmer.stem(t) for t in tokens]

    return tokens


def preprocess_dataset(dataset_name: str, dataset_path: str,
                        extra_stopwords: list[str] = None) -> dict:
    """
    Preprocess all requirements in a dataset.
    Returns and saves a dict:
    {
      "filename": {
          "raw":    "original text",
          "tokens": ["stemmed", "tokens", ...]
      }
    }
    """
    raw_reqs = load_requirements(dataset_path)

    processed = {}
    for fname, raw_text in raw_reqs.items():
        tokens = preprocess_text(raw_text, extra_stopwords)
        processed[fname] = {
            "raw":    raw_text,
            "tokens": tokens
        }

    # Save processed output
    os.makedirs(DATA_PROCESSED, exist_ok=True)
    out_path = os.path.join(DATA_PROCESSED, f"{dataset_name}_processed.json")
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(processed, f, indent=2)

    logger.info(f"Preprocessed {len(processed)} requirements : {out_path}")
    return processed


def load_processed(dataset_name: str) -> dict:
    """Load already-processed dataset from cache."""
    path = os.path.join(DATA_PROCESSED, f"{dataset_name}_processed.json")
    if not os.path.exists(path):
        raise FileNotFoundError(
            f"Processed file not found: {path}. Run preprocess_dataset() first."
        )
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)
