"""
fix_files.py — Run this once to fix all issues:
1. Replaces cluster.py with Ward linkage
2. Fixes kappa.py to use stemming for label comparison
3. Removes all Unicode arrow characters from all Python files
Run from inside the requirements_cluster_labeling folder:
    python fix_files.py
"""

import os

BASE = os.path.dirname(os.path.abspath(__file__))

# =============================================================================
# 1. Fix clustering/cluster.py — Ward linkage
# =============================================================================
cluster_py = os.path.join(BASE, "clustering", "cluster.py")
cluster_content = '''import os
import json
import logging
import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.cluster import AgglomerativeClustering

import sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from config import RESULTS_LOGS

logger = logging.getLogger(__name__)


def build_tfidf_matrix(processed):
    filenames = list(processed.keys())
    corpus = [" ".join(processed[f]["tokens"]) for f in filenames]
    vectorizer = TfidfVectorizer(min_df=1)
    tfidf_matrix = vectorizer.fit_transform(corpus)
    return tfidf_matrix, vectorizer, filenames


def cluster_requirements(processed, n_clusters, dataset_name=""):
    """Ward agglomerative clustering on TF-IDF — balanced clusters."""
    tfidf_matrix, vectorizer, filenames = build_tfidf_matrix(processed)

    model = AgglomerativeClustering(n_clusters=n_clusters, linkage="ward")
    labels = model.fit_predict(tfidf_matrix.toarray())

    clusters = {}
    for i in range(n_clusters):
        cluster_key = f"cluster_{i}"
        indices = [idx for idx, lbl in enumerate(labels) if lbl == i]
        clusters[cluster_key] = {
            "requirements": [filenames[idx] for idx in indices],
            "texts":        [processed[filenames[idx]]["raw"] for idx in indices],
            "tokens":       [processed[filenames[idx]]["tokens"] for idx in indices],
        }

    for k, v in clusters.items():
        logger.info(f"  {k}: {len(v[\'requirements\'])} requirements")

    if dataset_name:
        os.makedirs(RESULTS_LOGS, exist_ok=True)
        out_path = os.path.join(RESULTS_LOGS, f"{dataset_name}_clusters.json")
        save_data = {
            k: {"requirements": v["requirements"], "size": len(v["requirements"])}
            for k, v in clusters.items()
        }
        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(save_data, f, indent=2)
        logger.info(f"Cluster assignments saved: {out_path}")

    return clusters, vectorizer
'''

with open(cluster_py, "w", encoding="utf-8") as f:
    f.write(cluster_content)
print("Fixed: clustering/cluster.py (Ward linkage)")

# =============================================================================
# 2. Fix evaluation/kappa.py — stemming-aware label comparison
# =============================================================================
kappa_py = os.path.join(BASE, "evaluation", "kappa.py")
kappa_content = '''import os
import json
import logging
import sys
from nltk.stem import PorterStemmer

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from config import GOLD_DIR, KAPPA_LEVELS

logger = logging.getLogger(__name__)
stemmer = PorterStemmer()


def get_kappa_level(k):
    for low, high, label in KAPPA_LEVELS:
        if low <= k <= high:
            return label
    return "unknown"


def _normalize_labels(labels):
    """Stem each word in each label and return expanded set."""
    result = set()
    for label in labels:
        label = str(label).lower().strip()
        if not label or label == "[skipped]":
            continue
        words = label.split()
        # Add full stemmed phrase
        stemmed_phrase = " ".join(stemmer.stem(w) for w in words)
        result.add(stemmed_phrase)
        # Also add individual stemmed words
        for w in words:
            result.add(stemmer.stem(w))
    return result


def compute_kappa(automated_labels, gold_labels):
    """
    Compute Cohen\'s Kappa between automated and gold labels.
    Both sets are normalized via Porter stemming before comparison
    so that "patient registration" matches stemmed token "patient".
    """
    if not automated_labels or not gold_labels:
        return 0.0

    auto_set = _normalize_labels(automated_labels)
    gold_set = _normalize_labels(gold_labels)

    if not auto_set or not gold_set:
        return 0.0

    intersection = len(auto_set & gold_set)
    union        = len(auto_set | gold_set)

    if union == 0:
        return 0.0

    p_observed = intersection / union
    n_all      = union
    p_auto     = len(auto_set) / n_all
    p_gold     = len(gold_set) / n_all
    p_expected = p_auto * p_gold + (1 - p_auto) * (1 - p_gold)
    denominator = 1 - p_expected

    if denominator == 0:
        return 1.0 if p_observed == 1.0 else 0.0

    kappa = (p_observed - p_expected) / denominator
    return round(max(0.0, min(1.0, kappa)), 4)


def load_gold_standard(dataset_name):
    path = os.path.join(GOLD_DIR, f"{dataset_name}_gold.json")
    if not os.path.exists(path):
        raise FileNotFoundError(
            f"Gold standard not found: {path}\\n"
            f"Set USE_KAPPA = 0 in config.py or create the gold file."
        )
    with open(path, "r", encoding="utf-8") as f:
        data = json.load(f)
    # Remove _notes key if present
    return {k: v for k, v in data.items() if not k.startswith("_")}


def evaluate_kappa(dataset_name, all_labels):
    gold = load_gold_standard(dataset_name)
    method_kappas = {}

    for cluster_key, method_dict in all_labels.items():
        gold_labels = gold.get(cluster_key, [])
        if not gold_labels:
            continue
        for method, labels in method_dict.items():
            k = compute_kappa(labels, gold_labels)
            if method not in method_kappas:
                method_kappas[method] = []
            method_kappas[method].append(k)

    results = {}
    for method, kappas in method_kappas.items():
        avg_k = round(sum(kappas) / len(kappas), 4) if kappas else 0.0
        results[method] = {
            "kappa":     avg_k,
            "agreement": get_kappa_level(avg_k),
        }

    return results
'''

with open(kappa_py, "w", encoding="utf-8") as f:
    f.write(kappa_content)
print("Fixed: evaluation/kappa.py (stemming-aware Kappa)")

# =============================================================================
# 3. Fix Unicode arrow in preprocess.py
# =============================================================================
preprocess_py = os.path.join(BASE, "preprocessing", "preprocess.py")
with open(preprocess_py, "r", encoding="utf-8") as f:
    content = f.read()
content = content.replace("\u2192", ":")
with open(preprocess_py, "w", encoding="utf-8") as f:
    f.write(content)
print("Fixed: preprocessing/preprocess.py (Unicode arrows)")

# =============================================================================
# 4. Fix Unicode arrows in main.py
# =============================================================================
main_py = os.path.join(BASE, "main.py")
with open(main_py, "r", encoding="utf-8") as f:
    content = f.read()
content = content.replace("\u2192", ":")
# Also fix the Step 2 log message to say Ward
content = content.replace(
    "Step 2: Clustering (single-link agglomerative)...",
    "Step 2: Clustering (Ward agglomerative)..."
)
with open(main_py, "w", encoding="utf-8") as f:
    f.write(content)
print("Fixed: main.py (Unicode arrows + clustering label)")

# =============================================================================
# Done
# =============================================================================
print("\nAll fixes applied.")
print("Now run:")
print("  del data\\processed\\itrust_processed.json")
print("  python main.py --dataset itrust --no-llm")
