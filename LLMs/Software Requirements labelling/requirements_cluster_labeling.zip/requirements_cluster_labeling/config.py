# =============================================================================
# config.py — Central configuration for Requirements Cluster Labeling Pipeline
# =============================================================================

import os

# -----------------------------------------------------------------------------
# PATHS
# -----------------------------------------------------------------------------
BASE_DIR        = os.path.dirname(os.path.abspath(__file__))
DATA_RAW        = os.path.join(BASE_DIR, "data", "raw")
DATA_PROCESSED  = os.path.join(BASE_DIR, "data", "processed")
GOLD_DIR        = os.path.join(BASE_DIR, "data", "gold_standard")
RESULTS_TABLES  = os.path.join(BASE_DIR, "results", "tables")
RESULTS_LOGS    = os.path.join(BASE_DIR, "results", "logs")

# -----------------------------------------------------------------------------
# DATASETS
# -----------------------------------------------------------------------------
DATASETS = {
    "itrust": os.path.join(DATA_RAW, "itrust"),
    "etour":  os.path.join(DATA_RAW, "etour"),
    "cm1":    os.path.join(DATA_RAW, "cm1"),
}

DATASET_CLUSTERS = {
    "itrust": 10,
    "etour":  8,
    "cm1":    25,
}

GROUND_TRUTH = {
    "itrust": os.path.join(BASE_DIR, "data", "ground_truth", "itrust_ground.txt"),
    "etour":  os.path.join(BASE_DIR, "data", "ground_truth", "etour_ground.txt"),
    "cm1":    os.path.join(BASE_DIR, "data", "ground_truth", "cm1_ground.txt"),
}

# -----------------------------------------------------------------------------
# PREPROCESSING
# -----------------------------------------------------------------------------
STOPWORDS_EXTRA = ["shall", "system", "user", "able", "provide", "allow",
                   "use", "used", "using", "may", "also", "must",
                   "patient", "lhcp", "hcp", "itrust", "data", "list",
                   "name", "type", "select", "chosen", "choose", "enter",
                   "view", "information", "number", "click", "new",
                   "current", "exist", "display", "present", "show"]

# -----------------------------------------------------------------------------
# CLUSTERING
# -----------------------------------------------------------------------------
CLUSTER_SIZE_TARGET = 7

# -----------------------------------------------------------------------------
# LABELING
# -----------------------------------------------------------------------------
TOP_N_LABELS    = 10   # Labels to generate per cluster
TOP_N_KEYWORDS  = 10   # Keywords fed to LLM in Strategy B

# Strategy A: how many requirements to send to the LLM per cluster.
# Large clusters (50+ reqs) cause timeouts when the full text is sent.
# We sample the MAX_REQS_PER_CLUSTER most central requirements instead.
# Set to None to send all (only safe for small clusters / fast hardware).
MAX_REQS_PER_CLUSTER = 15

# -----------------------------------------------------------------------------
# LLM SETTINGS (Ollama)
# -----------------------------------------------------------------------------
OLLAMA_URL      = "http://localhost:11434"

# Per-request timeout in seconds.
# Mistral on CPU with 15 requirements takes ~60-90s.
# Increase if you have slower hardware or larger MAX_REQS_PER_CLUSTER.
OLLAMA_TIMEOUT  = 180

# Retry on timeout: how many times to retry with a reduced requirement count
# before giving up.  Each retry halves the number of requirements sent.
OLLAMA_RETRIES  = 2

MODELS          = ["llama3.2", "mistral"]
LLM_STRATEGIES  = ["A", "B"]

# -----------------------------------------------------------------------------
# EVALUATION
# -----------------------------------------------------------------------------
USE_KAPPA = 1

KAPPA_LEVELS = [
    (-1.00, -0.01, "poor"),
    ( 0.00,  0.20, "slight"),
    ( 0.21,  0.40, "fair"),
    ( 0.41,  0.60, "moderate"),
    ( 0.61,  0.80, "substantial"),
    ( 0.81,  1.00, "almost perfect"),
]

# -----------------------------------------------------------------------------
# OUTPUT
# -----------------------------------------------------------------------------
SAVE_RESULTS_CSV  = True
PRINT_RESULTS     = True
SAVE_CLUSTER_JSON = True
