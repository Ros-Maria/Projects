# =============================================================================
# evaluation/kappa.py
# Semantic Cohen's Kappa for cluster label evaluation.
#
# NORMALISATION FOR FAIR COMPARISON
# ----------------------------------
# Traditional methods (TF, Chi2, FPW) produce single keywords: 'appointment'
# LLM methods produce phrases: 'hospital appointment', 'office visit'
#
# Both are reduced to a single keyword before kappa scoring:
#   Traditional: already a keyword after unstemming ('appoint' -> 'appointment')
#   LLM:         head noun extracted from phrase     ('office visit' -> 'visit')
#
# This is stored in all_labels as:
#   traditional method: { method: ['appointment', 'diagnosis', ...] }
#   LLM method:         { method: {'display': [...], 'kappa': [...]} }
#
# evaluate_kappa() always uses the kappa keywords for scoring, never display.
#
# KAPPA FORMULA
# -------------
# Normalised hit-rate kappa:
#   hits  = (auto_matched + gold_covered) / (na + ng)
#   kappa = (hits - threshold) / (1 - threshold)
# where threshold = SIM_THRESHOLD = the expected-chance baseline.
# =============================================================================

import os
import json
import logging
import sys

from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
import numpy as np

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from config import GOLD_DIR, KAPPA_LEVELS

logger = logging.getLogger(__name__)

SIM_THRESHOLD = 0.35


def get_kappa_level(k: float) -> str:
    for low, high, label in KAPPA_LEVELS:
        if low <= k <= high:
            return label
    return "slight" if k >= 0.0 else "poor"


def _clean_labels(labels: list) -> list:
    """Lowercase, strip, drop empty / skipped entries."""
    cleaned = []
    for lbl in labels:
        lbl = str(lbl).lower().strip()
        if lbl and lbl != "[skipped]":
            cleaned.append(lbl)
    return cleaned


def _build_sim_matrix(auto_labels: list, gold_labels: list) -> np.ndarray:
    """Char-bigram TF-IDF cosine similarity matrix, shape (n_auto, n_gold)."""
    all_texts = list(auto_labels) + list(gold_labels)
    vect = TfidfVectorizer(analyzer="char_wb", ngram_range=(1, 2), min_df=1)
    tfidf = vect.fit_transform(all_texts)
    auto_vecs = tfidf[: len(auto_labels)]
    gold_vecs = tfidf[len(auto_labels):]
    return cosine_similarity(auto_vecs, gold_vecs)


def compute_kappa(automated_labels: list, gold_labels: list,
                  threshold: float = SIM_THRESHOLD) -> float:
    """
    Normalised hit-rate semantic kappa.
      kappa = (hits - threshold) / (1 - threshold)
    where hits = symmetric coverage rate between auto and gold label sets.
    """
    if not automated_labels or not gold_labels:
        return 0.0
    auto = _clean_labels(automated_labels)
    gold = _clean_labels(gold_labels)
    if not auto or not gold:
        return 0.0

    sim = _build_sim_matrix(auto, gold)
    na, ng = len(auto), len(gold)

    auto_matched = (sim.max(axis=1) >= threshold).sum()
    gold_covered = (sim.max(axis=0) >= threshold).sum()
    hits = (auto_matched + gold_covered) / (na + ng)

    denom = 1.0 - threshold
    if denom < 1e-9:
        return 1.0 if hits >= 0.999 else 0.0

    return round(float(max(-1.0, min(1.0, (hits - threshold) / denom))), 4)


def _get_kappa_labels(method: str, label_data) -> list:
    """
    Extract the kappa-ready keyword list from a method's label data.

    Traditional methods store a plain list: ['appointment', 'diagnosis', ...]
    LLM methods store a dict:              {'display': [...], 'kappa': [...]}

    Always returns the single-keyword list used for kappa scoring.
    """
    if isinstance(label_data, dict):
        return label_data.get("kappa", [])
    return label_data   # plain list from traditional methods


def load_gold_standard(dataset_name: str) -> dict:
    path = os.path.join(GOLD_DIR, f"{dataset_name}_gold.json")
    if not os.path.exists(path):
        raise FileNotFoundError(
            f"Gold standard not found: {path}\n"
            f"Run generate_gold.py first, or set USE_KAPPA = 0 in config.py."
        )
    with open(path, "r", encoding="utf-8") as f:
        data = json.load(f)
    return {k: v for k, v in data.items() if not k.startswith("_")}


def evaluate_kappa(dataset_name: str, all_labels: dict) -> dict:
    """
    Compute per-method average kappa across all clusters.

    Args:
        dataset_name: e.g. "itrust"
        all_labels:   {
          cluster_key: {
            'tf':         ['appointment', ...],             # plain list
            'llama3.2_A': {'display': [...], 'kappa': [...]}, # dict
            ...
          }
        }

    Returns:
        { method: {'kappa': float, 'agreement': str, 'n_clusters_scored': int} }
    """
    gold = load_gold_standard(dataset_name)

    auto_keys = set(all_labels.keys())
    gold_keys = set(gold.keys())
    missing   = auto_keys - gold_keys
    if missing:
        logger.warning(
            f"[Kappa | {dataset_name}] {len(missing)} clusters have no gold entry "
            f"and will be skipped: {sorted(missing)}\n"
            f"  -> Re-run generate_gold.py to fix."
        )

    method_kappas: dict[str, list] = {}

    for cluster_key, method_dict in all_labels.items():
        gold_labels = gold.get(cluster_key, [])
        if not gold_labels:
            continue

        for method, label_data in method_dict.items():
            kappa_labels = _get_kappa_labels(method, label_data)
            k = compute_kappa(kappa_labels, gold_labels)
            method_kappas.setdefault(method, []).append(k)
            logger.debug(
                f"[Kappa | {dataset_name} | {cluster_key} | {method}] "
                f"k={k}  labels={kappa_labels[:3]}"
            )

    results = {}
    for method, kappas in method_kappas.items():
        n     = len(kappas)
        avg_k = round(sum(kappas) / n, 4) if n else 0.0
        results[method] = {
            "kappa":             avg_k,
            "agreement":         get_kappa_level(avg_k),
            "n_clusters_scored": n,
        }
        logger.info(
            f"[Kappa | {dataset_name} | {method}] "
            f"k={avg_k} ({results[method]['agreement']})  (scored {n} clusters)"
        )

    return results
