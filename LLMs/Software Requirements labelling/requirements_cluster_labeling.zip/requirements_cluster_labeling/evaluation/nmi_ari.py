# =============================================================================
# evaluation/nmi_ari.py
# NMI and ARI evaluation — comparing pipeline clustering vs. ground truth.
# Uses the requirements-to-code traceability ground truth (ground.txt) to
# derive a "correct" grouping and measures clustering quality.
# No gold standard labels needed — fully automated.
# =============================================================================

import os
import logging
import sys
from sklearn.metrics import normalized_mutual_info_score, adjusted_rand_score

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

logger = logging.getLogger(__name__)


def parse_ground_truth(ground_txt_path: str) -> dict:
    """
    Parse ground.txt traceability file into a requirement → group mapping.

    The ground.txt maps each requirement to source code files.
    Requirements sharing the same dominant source code module are grouped together.

    Returns: { "UC1S1.txt": "GroupA", "UC2S1.txt": "GroupA", ... }
    """
    if not os.path.exists(ground_txt_path):
        raise FileNotFoundError(f"ground.txt not found: {ground_txt_path}")

    req_to_files = {}
    with open(ground_txt_path, "r", encoding="utf-8", errors="replace") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            parts = line.split()
            if len(parts) < 2:
                continue
            req_name    = parts[0]
            linked_files = parts[1:]
            req_to_files[req_name] = linked_files

    # Derive group labels: use the most common source file as the group label
    # This creates a natural functional grouping from the traceability links
    req_to_group = {}
    for req, files in req_to_files.items():
        if files:
            # Use the most frequently linked module as group representative
            from collections import Counter
            dominant = Counter(files).most_common(1)[0][0]
            # Simplify to module name (strip path, extension)
            module = os.path.splitext(os.path.basename(dominant))[0]
            req_to_group[req] = module

    return req_to_group


def build_label_arrays(clusters: dict,
                        req_to_group: dict) -> tuple:
    """
    Build parallel arrays of predicted and true labels for sklearn metrics.

    Only requirements that appear in BOTH the clusters and ground truth are used.

    Returns: (predicted_labels, true_labels, matched_req_count)
    """
    predicted = []
    true      = []

    for cluster_idx, (cluster_key, cluster_data) in enumerate(clusters.items()):
        for req_name in cluster_data["requirements"]:
            # Try exact match and case-insensitive match
            group = req_to_group.get(req_name) or req_to_group.get(req_name.upper())
            if group:
                predicted.append(cluster_idx)
                true.append(group)

    return predicted, true, len(predicted)


def evaluate_nmi_ari(clusters: dict, ground_txt_path: str,
                     dataset_name: str = "") -> dict:
    """
    Compute NMI and ARI between pipeline clusters and ground truth groupings.

    Args:
        clusters:         output of cluster_requirements()
        ground_txt_path:  path to dataset's ground.txt file
        dataset_name:     for logging

    Returns:
        {
          "nmi":     0.65,
          "ari":     0.42,
          "matched": 87,    # number of requirements matched to ground truth
          "total":   131,   # total requirements clustered
        }
    """
    try:
        req_to_group = parse_ground_truth(ground_txt_path)
    except FileNotFoundError as e:
        logger.warning(str(e))
        return {"nmi": None, "ari": None, "matched": 0, "total": 0}

    total_reqs = sum(len(c["requirements"]) for c in clusters.values())
    predicted, true, matched = build_label_arrays(clusters, req_to_group)

    if matched < 2:
        logger.warning(
            f"[NMI/ARI | {dataset_name}] Only {matched} requirements matched "
            f"ground truth. Need at least 2. Skipping."
        )
        return {"nmi": None, "ari": None, "matched": matched, "total": total_reqs}

    nmi = normalized_mutual_info_score(true, predicted, average_method="arithmetic")
    ari = adjusted_rand_score(true, predicted)

    result = {
        "nmi":     round(nmi, 4),
        "ari":     round(ari, 4),
        "matched": matched,
        "total":   total_reqs,
    }

    logger.info(
        f"[NMI/ARI | {dataset_name}] NMI={nmi:.4f}  ARI={ari:.4f}  "
        f"({matched}/{total_reqs} requirements matched to ground truth)"
    )
    return result
