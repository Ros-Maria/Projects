"""
diagnose.py — Diagnose both clustering and Kappa issues.
    python diagnose.py
"""
import os, sys, json
import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.cluster import AgglomerativeClustering
from collections import Counter
from nltk.stem import PorterStemmer

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

# ── 1. Load processed data ───────────────────────────────────────────────────
processed_path = os.path.join("data", "processed", "itrust_processed.json")
with open(processed_path, "r", encoding="utf-8") as f:
    processed = json.load(f)

filenames = list(processed.keys())
corpus = [" ".join(processed[f]["tokens"]) for f in filenames]

# ── 2. Check TF-IDF with min_df=2 ────────────────────────────────────────────
print("=== CLUSTERING DIAGNOSIS ===")
for min_df in [1, 2, 3]:
    vec = TfidfVectorizer(min_df=min_df, max_df=0.85)
    try:
        mat = vec.fit_transform(corpus)
        model = AgglomerativeClustering(n_clusters=5, linkage="ward")
        labels = model.fit_predict(mat.toarray())
        counts = Counter(labels)
        sizes = sorted(counts.values(), reverse=True)
        print(f"  min_df={min_df}, max_df=0.85, vocab={mat.shape[1]}: clusters={sizes}")
    except Exception as e:
        print(f"  min_df={min_df}: ERROR {e}")

print()

# Best approach: min_df=1, max_df=0.7 (remove very common terms)
print("Testing max_df thresholds (min_df=1):")
for max_df in [0.9, 0.8, 0.7, 0.6, 0.5]:
    vec = TfidfVectorizer(min_df=1, max_df=max_df)
    try:
        mat = vec.fit_transform(corpus)
        model = AgglomerativeClustering(n_clusters=5, linkage="ward")
        labels = model.fit_predict(mat.toarray())
        counts = Counter(labels)
        sizes = sorted(counts.values(), reverse=True)
        print(f"  max_df={max_df}, vocab={mat.shape[1]}: clusters={sizes}")
    except Exception as e:
        print(f"  max_df={max_df}: ERROR {e}")

print()

# ── 3. Kappa diagnosis ────────────────────────────────────────────────────────
print("=== KAPPA DIAGNOSIS ===")

# Load gold standard
gold_path = os.path.join("data", "gold_standard", "itrust_gold.json")
with open(gold_path, "r", encoding="utf-8") as f:
    gold = json.load(f)
gold = {k: v for k, v in gold.items() if not k.startswith("_")}

# Load latest labels
tables_dir = os.path.join("results", "tables")
label_files = sorted([f for f in os.listdir(tables_dir) if "itrust_labels" in f])
if label_files:
    latest = os.path.join(tables_dir, label_files[-1])
    with open(latest, "r", encoding="utf-8") as f:
        all_labels = json.load(f)

    print(f"Labels file: {label_files[-1]}")
    print()

    stemmer = PorterStemmer()

    # Show cluster_0 comparison
    cluster_key = "cluster_0"
    auto_tf = all_labels[cluster_key]["tf"]
    gold_labels = gold.get(cluster_key, [])

    print(f"Cluster 0 — TF labels (raw):  {auto_tf}")
    print(f"Cluster 0 — Gold labels:       {gold_labels}")
    print()

    # Stem gold labels
    def normalize(labels):
        result = set()
        for label in labels:
            label = str(label).lower().strip()
            words = label.split()
            result.add(" ".join(stemmer.stem(w) for w in words))
            for w in words:
                result.add(stemmer.stem(w))
        return result

    auto_norm = normalize(auto_tf)
    gold_norm = normalize(gold_labels)

    print(f"TF normalized (stemmed):   {sorted(auto_norm)[:10]}")
    print(f"Gold normalized (stemmed): {sorted(gold_norm)[:10]}")
    print(f"Intersection: {auto_norm & gold_norm}")
    print(f"Intersection size: {len(auto_norm & gold_norm)}")
    print(f"Union size: {len(auto_norm | gold_norm)}")

    if len(auto_norm & gold_norm) > 0:
        print("Kappa SHOULD be non-zero — kappa.py may not have been updated")
    else:
        print("No overlap found — gold labels need to be more specific to match stemmed tokens")
