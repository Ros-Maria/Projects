# Gold Standard Label Files — Instructions

## What is this folder?

This folder holds the **human expert label files** needed to compute Kappa scores
(comparing your automated labels against human judgment — same as the paper's Table V).

You do NOT need these files to run the pipeline.
They are only required when you set `USE_KAPPA = 1` in `config.py`.

---

## When to create these files

After you run the pipeline once with `USE_KAPPA = 0`, open the generated label files
in `results/tables/` and review the clusters. Then you and Dr. Reddivari can assign
10 expert labels per cluster and save them here.

---

## File naming

One file per dataset:

```
data/gold_standard/itrust_gold.json
data/gold_standard/etour_gold.json
data/gold_standard/cm1_gold.json
```

---

## File format

```json
{
  "cluster_0": [
    "patient management",
    "user authentication",
    "health records",
    "medical history",
    "doctor patient",
    "personal health",
    "hospital system",
    "prescription management",
    "office visit",
    "healthcare provider"
  ],
  "cluster_1": [
    "label1",
    "label2",
    "..."
  ]
}
```

**Rules:**
- Exactly 10 labels per cluster (to match the paper's methodology)
- Labels should be 1–3 words, lowercase
- Cluster keys must match exactly: `cluster_0`, `cluster_1`, etc.
- Check your cluster count in `config.py → DATASET_CLUSTERS`
  - iTrust: 5 clusters → keys cluster_0 through cluster_4
  - eTour:  8 clusters → keys cluster_0 through cluster_7
  - CM-1:  25 clusters → keys cluster_0 through cluster_24

---

## Template file

Below is a ready-to-fill template for iTrust (5 clusters).
Copy, rename to `itrust_gold.json`, and fill in the labels.

```json
{
  "cluster_0": ["FILL_IN", "FILL_IN", "FILL_IN", "FILL_IN", "FILL_IN",
                "FILL_IN", "FILL_IN", "FILL_IN", "FILL_IN", "FILL_IN"],
  "cluster_1": ["FILL_IN", "FILL_IN", "FILL_IN", "FILL_IN", "FILL_IN",
                "FILL_IN", "FILL_IN", "FILL_IN", "FILL_IN", "FILL_IN"],
  "cluster_2": ["FILL_IN", "FILL_IN", "FILL_IN", "FILL_IN", "FILL_IN",
                "FILL_IN", "FILL_IN", "FILL_IN", "FILL_IN", "FILL_IN"],
  "cluster_3": ["FILL_IN", "FILL_IN", "FILL_IN", "FILL_IN", "FILL_IN",
                "FILL_IN", "FILL_IN", "FILL_IN", "FILL_IN", "FILL_IN"],
  "cluster_4": ["FILL_IN", "FILL_IN", "FILL_IN", "FILL_IN", "FILL_IN",
                "FILL_IN", "FILL_IN", "FILL_IN", "FILL_IN", "FILL_IN"]
}
```

---

## Workflow tip

Run this command first to see what requirements are in each cluster:

```
python main.py --dataset itrust --no-llm
```

Then open `results/tables/itrust_labels_*.json` to review cluster contents
before assigning expert labels.
