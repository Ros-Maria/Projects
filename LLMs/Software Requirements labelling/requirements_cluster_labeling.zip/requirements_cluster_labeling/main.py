# =============================================================================
# main.py — Master pipeline runner
#
# Runs the full Requirements Cluster Labeling pipeline:
#   1. Preprocess requirements
#   2. Cluster (Ward agglomerative)
#   3. Label clusters:
#        Traditional (TF, Chi2, FPW) → plain keyword lists
#        LLM (Strategy A/B)          → {'display': [...], 'kappa': [...]}
#          display  : natural phrases for human output ('office visit')
#          kappa    : head nouns for fair comparison   ('visit')
#   4a. Evaluate clustering quality: NMI / ARI
#   4b. Auto-regenerate gold standard (keeps cluster count in sync)
#   4c. Evaluate label quality: Kappa
#   5. Save results tables
#
# Usage:
#   python main.py                    # run all datasets, all models
#   python main.py --dataset itrust   # run one dataset only
#   python main.py --no-llm           # skip LLM labeling (faster)
# =============================================================================

import os
import sys
import json
import logging
import argparse
import csv
from datetime import datetime

from config import (
    DATASETS, DATASET_CLUSTERS, STOPWORDS_EXTRA,
    MODELS, LLM_STRATEGIES, TOP_N_LABELS,
    USE_KAPPA, RESULTS_TABLES, RESULTS_LOGS,
    SAVE_RESULTS_CSV, PRINT_RESULTS, SAVE_CLUSTER_JSON
)
from preprocessing.preprocess import preprocess_dataset, load_processed
from clustering.cluster import cluster_requirements
from labeling.traditional.tf_labeler   import get_tf_labels
from labeling.traditional.chi2_labeler import get_chi2_labels
from labeling.traditional.fpw_labeler  import get_fpw_labels
from labeling.llm.ollama_client import check_model_available, list_available_models
from labeling.llm.strategy_a    import get_llm_strategy_a_labels
from labeling.llm.strategy_b    import get_llm_strategy_b_labels
from evaluation.nmi_ari import evaluate_nmi_ari

if USE_KAPPA == 1:
    from evaluation.kappa import evaluate_kappa
    from generate_gold import generate_gold_from_labels

# ---------------------------------------------------------------------------
# Logging
# ---------------------------------------------------------------------------
os.makedirs(RESULTS_LOGS, exist_ok=True)
log_file = os.path.join(
    RESULTS_LOGS, f"run_{datetime.now().strftime('%Y%m%d_%H%M%S')}.log"
)
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    handlers=[
        logging.FileHandler(log_file),
        logging.StreamHandler(sys.stdout),
    ]
)
logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def get_ground_txt_path(dataset_name: str) -> str | None:
    from config import GROUND_TRUTH
    path = GROUND_TRUTH.get(dataset_name, "")
    return path if os.path.exists(path) else None


def label_all_clusters(clusters: dict, models: list, run_llm: bool) -> dict:
    """
    Run all labeling methods on all clusters.

    Returns:
    {
      "cluster_0": {
          "tf":         ['appointment', 'diagnosis', ...],   # plain list
          "chi2":       ['appointment', ...],
          "fpw":        ['appointment', ...],
          "llama3.2_A": {'display': ['office visit', ...],   # dict with two views
                         'kappa':   ['visit', ...]},
          "llama3.2_B": {'display': [...], 'kappa': [...]},
          "mistral_A":  {'display': [...], 'kappa': [...]},
          "mistral_B":  {'display': [...], 'kappa': [...]},
      },
      ...
    }

    Traditional methods produce single unstemmed keywords directly.
    LLM methods produce natural phrases (display) and their head nouns (kappa).
    kappa.py's _get_kappa_labels() handles both formats transparently.
    """
    all_labels = {}

    for cluster_key, cluster in clusters.items():
        logger.info(f"  Labeling {cluster_key} ({len(cluster['requirements'])} reqs)...")
        labels = {}

        # Traditional methods — return plain keyword lists (already unstemmed)
        labels["tf"]   = get_tf_labels(cluster, TOP_N_LABELS)
        labels["chi2"] = get_chi2_labels(cluster, clusters, TOP_N_LABELS)
        labels["fpw"]  = get_fpw_labels(cluster, clusters, TOP_N_LABELS)

        # LLM methods — return {'display': [...], 'kappa': [...]}
        if run_llm:
            for model in models:
                if not check_model_available(model):
                    logger.warning(
                        f"  Model '{model}' not found in Ollama. "
                        f"Available: {list_available_models()}. Skipping."
                    )
                    labels[f"{model}_A"] = {"display": [], "kappa": []}
                    labels[f"{model}_B"] = {"display": [], "kappa": []}
                    continue

                for strategy in LLM_STRATEGIES:
                    method_key = f"{model}_{strategy}"
                    logger.info(f"    Running: {method_key}")
                    if strategy == "A":
                        labels[method_key] = get_llm_strategy_a_labels(
                            cluster, model, TOP_N_LABELS
                        )
                    else:
                        labels[method_key] = get_llm_strategy_b_labels(
                            cluster, clusters, model, TOP_N_LABELS
                        )
        else:
            for model in models:
                labels[f"{model}_A"] = {"display": ["[skipped]"], "kappa": []}
                labels[f"{model}_B"] = {"display": ["[skipped]"], "kappa": []}

        all_labels[cluster_key] = labels

    return all_labels


def print_results_table(dataset_name: str, nmi_ari: dict,
                         kappa_results: dict = None):
    """Print a formatted results summary to console."""
    print(f"\n{'='*65}")
    print(f"  RESULTS — {dataset_name.upper()}")
    print(f"{'='*65}")

    print(f"\n  Clustering Quality (NMI / ARI):")
    if nmi_ari.get("nmi") is not None:
        print(f"    NMI : {nmi_ari['nmi']:.4f}")
        print(f"    ARI : {nmi_ari['ari']:.4f}")
        print(f"    Matched {nmi_ari['matched']}/{nmi_ari['total']} to ground truth")
    else:
        print("    NMI/ARI: Could not compute")

    if kappa_results:
        print(f"\n  Label Quality vs. Gold Standard (keyword-normalised kappa):")
        print(f"  {'Method':<20} {'Kappa':>7}  {'Agreement':<16}  {'Clusters':>8}")
        print(f"  {'-'*55}")
        for method, res in sorted(kappa_results.items(),
                                   key=lambda x: x[1]["kappa"], reverse=True):
            print(
                f"  {method:<20} {res['kappa']:>7.4f}  {res['agreement']:<16}  "
                f"{res['n_clusters_scored']:>8}"
            )
    elif USE_KAPPA == 0:
        print("\n  Kappa: DISABLED (USE_KAPPA = 0 in config.py)")

    print(f"{'='*65}\n")


def save_results_csv(dataset_name: str, nmi_ari: dict,
                      kappa_results: dict, all_labels: dict):
    """Save full results to CSV files."""
    os.makedirs(RESULTS_TABLES, exist_ok=True)
    ts = datetime.now().strftime("%Y%m%d_%H%M%S")

    # NMI/ARI
    nmi_path = os.path.join(RESULTS_TABLES, f"{dataset_name}_nmi_ari_{ts}.csv")
    with open(nmi_path, "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["metric", "value"])
        w.writerow(["NMI",     nmi_ari.get("nmi",     "N/A")])
        w.writerow(["ARI",     nmi_ari.get("ari",     "N/A")])
        w.writerow(["matched", nmi_ari.get("matched", "N/A")])
        w.writerow(["total",   nmi_ari.get("total",   "N/A")])
    logger.info(f"NMI/ARI: {nmi_path}")

    # Kappa
    if kappa_results:
        kappa_path = os.path.join(RESULTS_TABLES, f"{dataset_name}_kappa_{ts}.csv")
        with open(kappa_path, "w", newline="", encoding="utf-8") as f:
            w = csv.writer(f)
            w.writerow(["method", "kappa", "agreement", "n_clusters_scored"])
            for method, res in kappa_results.items():
                w.writerow([method, res["kappa"], res["agreement"],
                             res["n_clusters_scored"]])
        logger.info(f"Kappa:   {kappa_path}")

    # Full labels JSON — serialise both plain lists and display/kappa dicts
    if SAVE_CLUSTER_JSON:
        labels_path = os.path.join(RESULTS_TABLES, f"{dataset_name}_labels_{ts}.json")
        with open(labels_path, "w", encoding="utf-8") as f:
            json.dump(all_labels, f, indent=2)
        logger.info(f"Labels:  {labels_path}")


# ---------------------------------------------------------------------------
# Main pipeline
# ---------------------------------------------------------------------------

def run_pipeline(dataset_name: str, run_llm: bool = True):
    dataset_path = DATASETS.get(dataset_name)
    if not dataset_path or not os.path.exists(dataset_path):
        logger.error(f"Dataset '{dataset_name}' not found: {dataset_path}")
        return

    n_clusters = DATASET_CLUSTERS.get(dataset_name, 5)
    logger.info(f"\n{'='*60}")
    logger.info(f"DATASET: {dataset_name.upper()}  |  Target clusters: {n_clusters}")
    logger.info(f"{'='*60}")

    logger.info("Step 1: Preprocessing...")
    processed = preprocess_dataset(dataset_name, dataset_path, STOPWORDS_EXTRA)
    logger.info(f"  {len(processed)} requirements preprocessed.")

    logger.info("Step 2: Clustering...")
    clusters, vectorizer = cluster_requirements(processed, n_clusters, dataset_name)
    logger.info(f"  {len(clusters)} clusters created.")

    logger.info("Step 3: Labeling...")
    all_labels = label_all_clusters(clusters, MODELS, run_llm)

    logger.info("Step 4a: NMI/ARI...")
    ground_txt = get_ground_txt_path(dataset_name)
    nmi_ari = (
        evaluate_nmi_ari(clusters, ground_txt, dataset_name)
        if ground_txt
        else {"nmi": None, "ari": None, "matched": 0, "total": len(processed)}
    )

    kappa_results = None
    if USE_KAPPA == 1:
        # Save labels first so generate_gold can load them
        os.makedirs(RESULTS_TABLES, exist_ok=True)
        ts_pre = datetime.now().strftime("%Y%m%d_%H%M%S")
        labels_path_pre = os.path.join(
            RESULTS_TABLES, f"{dataset_name}_labels_{ts_pre}.json"
        )
        with open(labels_path_pre, "w", encoding="utf-8") as f:
            json.dump(all_labels, f, indent=2)

        logger.info("Step 4b: Regenerating gold standard...")
        generate_gold_from_labels(dataset_name)

        logger.info("Step 4c: Kappa evaluation...")
        try:
            kappa_results = evaluate_kappa(dataset_name, all_labels)
        except FileNotFoundError as e:
            logger.error(str(e))
    else:
        logger.info("Step 4b/c: Kappa SKIPPED (USE_KAPPA=0).")

    if PRINT_RESULTS:
        print_results_table(dataset_name, nmi_ari, kappa_results)

    if SAVE_RESULTS_CSV:
        save_results_csv(dataset_name, nmi_ari, kappa_results, all_labels)

    return {
        "clusters":      clusters,
        "all_labels":    all_labels,
        "nmi_ari":       nmi_ari,
        "kappa_results": kappa_results,
    }


def main():
    parser = argparse.ArgumentParser(description="Requirements Cluster Labeling Pipeline")
    parser.add_argument("--dataset", type=str, default=None)
    parser.add_argument("--no-llm", action="store_true")
    args = parser.parse_args()

    datasets_to_run = [args.dataset] if args.dataset else list(DATASETS.keys())
    run_llm = not args.no_llm

    logger.info(f"Datasets: {datasets_to_run} | LLM: {run_llm} | USE_KAPPA: {USE_KAPPA}")

    for ds in datasets_to_run:
        run_pipeline(ds, run_llm=run_llm)

    logger.info("Pipeline complete.")


if __name__ == "__main__":
    main()
