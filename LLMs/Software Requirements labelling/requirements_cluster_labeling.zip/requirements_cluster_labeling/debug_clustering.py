"""
debug_clustering.py — Run to see what's happening with clustering.
    python debug_clustering.py
"""
import os, sys, json
import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.cluster import AgglomerativeClustering
from collections import Counter

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

# Load processed data
processed_path = os.path.join("data", "processed", "itrust_processed.json")
if not os.path.exists(processed_path):
    print("ERROR: Run pipeline first to generate processed data.")
    sys.exit(1)

with open(processed_path, "r", encoding="utf-8") as f:
    processed = json.load(f)

filenames = list(processed.keys())
corpus = [" ".join(processed[f]["tokens"]) for f in filenames]

print(f"Total requirements: {len(filenames)}")
print(f"Avg tokens per requirement: {np.mean([len(processed[f]['tokens']) for f in filenames]):.1f}")
print(f"Min tokens: {min(len(processed[f]['tokens']) for f in filenames)}")
print(f"Max tokens: {max(len(processed[f]['tokens']) for f in filenames)}")
print()

# Check empty/near-empty requirements
short = [(f, len(processed[f]["tokens"])) for f in filenames if len(processed[f]["tokens"]) < 5]
print(f"Requirements with < 5 tokens ({len(short)}):")
for fname, n in short[:10]:
    print(f"  {fname}: {n} tokens -> '{processed[fname]['raw'][:80]}'")
print()

# Try Ward with different n_clusters
vectorizer = TfidfVectorizer(min_df=1)
tfidf = vectorizer.fit_transform(corpus)

print("Cluster size distribution for n_clusters=5:")
model = AgglomerativeClustering(n_clusters=5, linkage="ward")
labels = model.fit_predict(tfidf.toarray())
counts = Counter(labels)
for k in sorted(counts):
    print(f"  cluster_{k}: {counts[k]} requirements")

print()
print("Vocabulary size:", len(vectorizer.get_feature_names_out()))
print()

# Check what the 97-requirement cluster contains
print("Checking dominant cluster — top 10 most common tokens:")
dominant_cluster = counts.most_common(1)[0][0]
tokens_in_cluster = []
for idx, lbl in enumerate(labels):
    if lbl == dominant_cluster:
        tokens_in_cluster.extend(processed[filenames[idx]]["tokens"])
from collections import Counter as C
top = C(tokens_in_cluster).most_common(10)
print(f"  Cluster {dominant_cluster} ({counts[dominant_cluster]} reqs):", top)
