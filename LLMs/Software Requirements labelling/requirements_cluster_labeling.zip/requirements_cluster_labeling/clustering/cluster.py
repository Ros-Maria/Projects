import os
import json
import logging
import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.cluster import AgglomerativeClustering

import sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from config import RESULTS_LOGS

logger = logging.getLogger(__name__)


def build_tfidf_matrix(processed):
    filenames = list(processed.keys())
    corpus = [" ".join(processed[f]["tokens"]) for f in filenames]
    vectorizer = TfidfVectorizer(min_df=1)
    tfidf_matrix = vectorizer.fit_transform(corpus)
    return tfidf_matrix, vectorizer, filenames


def cluster_requirements(processed, n_clusters, dataset_name=""):
    """Ward agglomerative clustering on TF-IDF — balanced clusters."""
    tfidf_matrix, vectorizer, filenames = build_tfidf_matrix(processed)

    model = AgglomerativeClustering(n_clusters=n_clusters, linkage="ward")
    labels = model.fit_predict(tfidf_matrix.toarray())

    clusters = {}
    for i in range(n_clusters):
        cluster_key = f"cluster_{i}"
        indices = [idx for idx, lbl in enumerate(labels) if lbl == i]
        clusters[cluster_key] = {
            "requirements": [filenames[idx] for idx in indices],
            "texts":        [processed[filenames[idx]]["raw"] for idx in indices],
            "tokens":       [processed[filenames[idx]]["tokens"] for idx in indices],
        }

    for k, v in clusters.items():
        logger.info(f"  {k}: {len(v['requirements'])} requirements")

    if dataset_name:
        os.makedirs(RESULTS_LOGS, exist_ok=True)
        out_path = os.path.join(RESULTS_LOGS, f"{dataset_name}_clusters.json")
        save_data = {
            k: {"requirements": v["requirements"], "size": len(v["requirements"])}
            for k, v in clusters.items()
        }
        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(save_data, f, indent=2)
        logger.info(f"Cluster assignments saved: {out_path}")

    return clusters, vectorizer
