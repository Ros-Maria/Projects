# =============================================================================
# labeling/traditional/tf_labeler.py
# Term Frequency (TF) based cluster labeling.
# Returns unstemmed surface forms by reverse-mapping stems back to the most
# frequent original word in the cluster's raw texts.
# =============================================================================

from collections import Counter
from labeling.traditional._unstem import build_stem_to_surface, unstem


def get_tf_labels(cluster: dict, top_n: int = 10) -> list[str]:
    """
    Args:
        cluster: dict with "tokens" (stemmed) and "texts" (raw requirement strings)
        top_n:   number of top labels to return
    Returns:
        List of top_n most-frequent terms as clean unstemmed surface words.
    """
    all_stemmed: list[str] = []
    for token_list in cluster["tokens"]:
        all_stemmed.extend(token_list)

    stem_map = build_stem_to_surface(cluster.get("texts", []))

    counter = Counter(all_stemmed)
    top_stemmed = [term for term, _ in counter.most_common(top_n)]
    return [unstem(s, stem_map) for s in top_stemmed]
