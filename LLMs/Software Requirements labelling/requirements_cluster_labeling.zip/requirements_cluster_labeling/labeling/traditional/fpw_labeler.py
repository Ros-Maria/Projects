# =============================================================================
# labeling/traditional/fpw_labeler.py
# Frequent and Predictive Words (FPW) — cluster-level TF-IDF.
# Returns unstemmed surface forms by reverse-mapping stems back to the most
# frequent original word in the cluster's raw texts.
# =============================================================================

import math
from collections import Counter
from labeling.traditional._unstem import build_stem_to_surface, unstem


def get_fpw_labels(target_cluster: dict, all_clusters: dict,
                   top_n: int = 10) -> list[str]:
    """
    FPW score = TF_in_cluster * log((N_clusters + 1) / (df_term + 1))

    Args:
        target_cluster: dict with "tokens" and "texts"
        all_clusters:   full dict of all clusters
        top_n:          number of labels to return
    Returns:
        List of top_n labels as clean unstemmed surface words.
    """
    N_clusters = len(all_clusters)

    target_tokens: list[str] = []
    for tok_list in target_cluster["tokens"]:
        target_tokens.extend(tok_list)
    tf = Counter(target_tokens)

    stem_map = build_stem_to_surface(target_cluster.get("texts", []))

    df: Counter = Counter()
    for cluster in all_clusters.values():
        cluster_vocab: set[str] = set()
        for tok_list in cluster["tokens"]:
            cluster_vocab.update(tok_list)
        for term in cluster_vocab:
            df[term] += 1

    fpw_scores: dict[str, float] = {}
    for term, freq in tf.items():
        idf = math.log((N_clusters + 1) / (df.get(term, 1) + 1))
        fpw_scores[term] = freq * idf

    sorted_terms = sorted(fpw_scores.items(), key=lambda x: x[1], reverse=True)
    top_stemmed  = [term for term, _ in sorted_terms[:top_n]]
    return [unstem(s, stem_map) for s in top_stemmed]
