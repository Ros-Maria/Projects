# =============================================================================
# labeling/traditional/_unstem.py
# Recovers the best unstemmed surface form for a stemmed token.
#
# Strategy: stem every word from the raw requirement texts using the same
# PorterStemmer used in preprocessing, then for each stem keep the most
# frequent original surface word. This gives a reliable stem -> surface map
# with no prefix-guessing heuristics.
# =============================================================================

import re
from collections import Counter
from nltk.stem import PorterStemmer

_stemmer = PorterStemmer()


def build_stem_to_surface(texts: list[str]) -> dict[str, str]:
    """
    Build a mapping  stemmed_token -> most_frequent_surface_word
    from a list of raw requirement text strings.

    Uses the same PorterStemmer as preprocessing so the stems match exactly.
    No stopword list needed — we look up whatever stem the labeler gives us.
    """
    stem_surface: dict[str, Counter] = {}

    for text in texts:
        # Same tokenisation as preprocessing: lowercase, alpha only, len > 2
        words = re.findall(r"[a-z]+", text.lower())
        for w in words:
            if len(w) > 2:
                stem = _stemmer.stem(w)
                stem_surface.setdefault(stem, Counter())[w] += 1

    return {
        stem: cnt.most_common(1)[0][0]
        for stem, cnt in stem_surface.items()
    }


def unstem(stemmed_token: str, stem_to_surface: dict[str, str]) -> str:
    """Return the best surface word for a stem; fall back to the stem itself."""
    return stem_to_surface.get(stemmed_token, stemmed_token)
