# =============================================================================
# labeling/traditional/chi2_labeler.py
# Chi-squared (χ²) based cluster labeling.
# Returns unstemmed surface forms by reverse-mapping stems back to the most
# frequent original word in the cluster's raw texts.
# =============================================================================

from collections import Counter
from labeling.traditional._unstem import build_stem_to_surface, unstem


def get_chi2_labels(target_cluster: dict, all_clusters: dict,
                    top_n: int = 10) -> list[str]:
    """
    Args:
        target_cluster: dict with "tokens" and "texts"
        all_clusters:   full dict of all clusters
        top_n:          number of labels to return
    Returns:
        List of top_n most-discriminative labels as clean unstemmed surface words.
    """
    target_tokens: list[str] = []
    for tok_list in target_cluster["tokens"]:
        target_tokens.extend(tok_list)
    target_count = Counter(target_tokens)
    N_target = sum(target_count.values())

    stem_map = build_stem_to_surface(target_cluster.get("texts", []))

    all_tokens: list[str] = []
    for cluster in all_clusters.values():
        for tok_list in cluster["tokens"]:
            all_tokens.extend(tok_list)
    total_count = Counter(all_tokens)
    N_total = sum(total_count.values())
    N_other = N_total - N_target

    if N_total == 0 or N_target == 0:
        return []

    chi2_scores: dict[str, float] = {}
    vocab = set(target_count.keys()) | set(total_count.keys())

    for term in vocab:
        A = target_count.get(term, 0)
        B = N_target - A
        C = total_count.get(term, 0) - A
        D = N_other - C
        N = A + B + C + D
        if N == 0:
            continue
        numerator   = N * ((A * D - B * C) ** 2)
        denominator = (A + B) * (C + D) * (A + C) * (B + D)
        if denominator == 0:
            continue
        chi2_scores[term] = numerator / denominator

    sorted_terms = sorted(chi2_scores.items(), key=lambda x: x[1], reverse=True)
    top_stemmed  = [term for term, _ in sorted_terms[:top_n]]
    return [unstem(s, stem_map) for s in top_stemmed]
