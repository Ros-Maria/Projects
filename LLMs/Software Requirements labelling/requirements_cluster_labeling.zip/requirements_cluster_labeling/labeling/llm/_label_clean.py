# =============================================================================
# labeling/llm/_label_clean.py
# Normalises raw LLM label output to a single keyword per label.
#
# DESIGN RATIONALE
# ----------------
# Traditional methods (TF, Chi2, FPW) produce single stemmed tokens which
# are then unstemmed to surface forms: 'appoint' -> 'appointment'.
#
# LLM methods produce richer labels: 'hospital appointment', 'office visit',
# 'diagnosisCoding', 'icd10 (assuming...)'.  Comparing these directly against
# single-word traditional labels via char-ngram kappa is unfair — a 2-word
# phrase scores lower than a 1-word match even when they mean the same thing.
#
# FIX: reduce every LLM label to its HEAD NOUN — the single most semantically
# central word — before kappa scoring.
#
#   'hospital appointment'  -> 'appointment'   (last content word)
#   'office visit'          -> 'visit'
#   'diagnostic coding'     -> 'coding'
#   'diagnosisCoding'       -> 'coding'        (split camelCase first, then head)
#   'bloodPressure'         -> 'pressure'
#   'icd10 (assuming ...)'  -> 'icd10'         (strip parens, then head)
#   'prescription'          -> 'prescription'  (already single word)
#
# Head noun = last non-stopword token in the label (standard NLP convention
# for English noun phrases).  For single-word labels it is the word itself.
#
# Two separate outputs are produced:
#   display_label  : full clean phrase for human-readable output  ('office visit')
#   kappa_keyword  : single head noun for kappa comparison        ('visit')
# =============================================================================

import re

# Minimal stopword list — words that should not be selected as the head noun
# even if they appear last (prepositions, articles, etc.)
_STOPWORDS = {
    'a', 'an', 'the', 'of', 'for', 'in', 'on', 'at', 'by', 'to', 'and',
    'or', 'with', 'from', 'as', 'is', 'are', 'was', 'be', 'been', 'has',
}


def _strip_paren(text: str) -> str:
    """Remove parenthetical content: 'icd10 (assuming ...)' -> 'icd10'."""
    return re.sub(r"\s*\(.*?\)", "", text).strip()


def _split_camel(token: str) -> list[str]:
    """
    Split camelCase / PascalCase into words.
    Called BEFORE lowercasing so uppercase letters are still visible.
      'officeVisit'    -> ['office', 'Visit']
      'diagnosisCoding'-> ['diagnosis', 'Coding']
    """
    return re.sub(r"([a-z])([A-Z])", r"\1 \2", token).split()


def _tokenise(raw: str) -> list[str]:
    """
    Full tokenisation pipeline for one raw label string:
      1. Strip parentheticals (before splitting)
      2. Split on whitespace / hyphens / underscores
      3. Split camelCase within each part (before lowercasing)
      4. Lowercase
      5. Strip leading/trailing non-alphanumeric characters
      6. Drop tokens shorter than 3 characters
    """
    raw = _strip_paren(raw)

    parts: list[str] = re.split(r"[\s\-_]+", raw)

    tokens: list[str] = []
    for part in parts:
        for word in _split_camel(part):
            word = re.sub(r"^[^a-z0-9]+|[^a-z0-9]+$", "", word.lower())
            if len(word) >= 3:
                tokens.append(word)

    return tokens


def extract_head_noun(tokens: list[str]) -> str:
    """
    Return the head noun of a tokenised label.
    Head noun = last token that is not a stopword.
    Falls back to the last token if all are stopwords.
    """
    for token in reversed(tokens):
        if token not in _STOPWORDS:
            return token
    return tokens[-1] if tokens else ""


def normalise_label(raw: str) -> tuple[str, str]:
    """
    Normalise one raw LLM label string.

    Returns:
        display_label : clean phrase for human-readable output
        kappa_keyword : single head noun for kappa comparison

    Examples:
        'hospital appointment' -> ('hospital appointment', 'appointment')
        'officeVisit'          -> ('office visit',         'visit')
        'diagnosisCoding'      -> ('diagnosis coding',     'coding')
        'icd10 (assuming ...)'  -> ('icd10',               'icd10')
        'prescription'         -> ('prescription',         'prescription')
    """
    tokens = _tokenise(raw)
    if not tokens:
        return ("", "")

    display = " ".join(tokens)
    keyword = extract_head_noun(tokens)
    return display, keyword


def parse_llm_response(response: str, top_n: int) -> tuple[list[str], list[str]]:
    """
    Parse a numbered-list LLM response and return two parallel lists of
    length <= top_n:
        display_labels : full clean phrases  ['office visit', 'diagnosis', ...]
        kappa_keywords : head nouns only     ['visit',        'diagnosis', ...]

    Handles:
        '1. appointment'
        '1) bloodPressure'
        '- office visit'
        'icd10 (assuming icd stands for international classification of diseases)'
    """
    if not response:
        return [], []

    display_labels: list[str] = []
    kappa_keywords: list[str] = []
    seen_keywords:  set[str]  = set()

    lines = response.strip().split("\n")

    for line in lines:
        line = line.strip()
        if not line:
            continue

        # Remove leading list markers — preserve original case for camelCase split
        line = re.sub(r"^[\d]+[.)]\s*", "", line)
        line = re.sub(r"^[-•]\s*",       "", line)
        line = line.strip()

        if not line:
            continue

        display, keyword = normalise_label(line)

        if not keyword or keyword in seen_keywords:
            continue

        seen_keywords.add(keyword)
        display_labels.append(display)
        kappa_keywords.append(keyword)

        if len(kappa_keywords) >= top_n:
            break

    return display_labels, kappa_keywords
