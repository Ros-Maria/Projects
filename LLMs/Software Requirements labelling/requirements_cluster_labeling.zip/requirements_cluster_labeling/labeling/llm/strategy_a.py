# =============================================================================
# labeling/llm/strategy_a.py
# LLM Strategy A: Feed representative requirement texts to the LLM.
#
# TIMEOUT FIX
# -----------
# Large clusters (50+ requirements) caused timeouts when all text was sent.
# Fix: select the MAX_REQS_PER_CLUSTER most central requirements instead of
# all of them.  "Most central" = requirements whose TF-IDF vector is closest
# to the cluster centroid, so the LLM sees the most representative content.
#
# On timeout, the strategy retries with half as many requirements, down to
# a minimum of 3, before giving up.
# =============================================================================

import logging
import sys
import os

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
from config import TOP_N_LABELS, MAX_REQS_PER_CLUSTER, OLLAMA_RETRIES
from labeling.llm.ollama_client import query_ollama
from labeling.llm._label_clean import parse_llm_response

logger = logging.getLogger(__name__)


def _select_central_reqs(cluster: dict, max_reqs: int) -> list[str]:
    """
    Return up to max_reqs requirement texts, ordered by centrality.

    Centrality = cosine similarity to the cluster centroid in TF-IDF space.
    Falls back to simple truncation if sklearn is unavailable.
    If the cluster has <= max_reqs requirements, all are returned.
    """
    texts = cluster.get("texts", [])
    if not texts:
        return []
    if max_reqs is None or len(texts) <= max_reqs:
        return texts

    try:
        from sklearn.feature_extraction.text import TfidfVectorizer
        from sklearn.metrics.pairwise import cosine_similarity
        import numpy as np

        vect   = TfidfVectorizer(max_features=500, stop_words="english")
        tfidf  = vect.fit_transform(texts)
        centroid = tfidf.mean(axis=0)
        sims   = cosine_similarity(tfidf, centroid).flatten()
        top_idx = np.argsort(sims)[::-1][:max_reqs]
        # Keep original order for readability
        selected_idx = sorted(top_idx)
        return [texts[i] for i in selected_idx]
    except Exception:
        # Fallback: just take the first max_reqs
        return texts[:max_reqs]


def _build_prompt(texts: list[str], top_n: int) -> str:
    combined = "\n\n".join(
        [f"Requirement {i+1}: {t}" for i, t in enumerate(texts)]
    )
    return f"""You are an expert in software requirements engineering.
Below is a group of related software requirements that belong to the same cluster.

{combined}

Generate exactly {top_n} short topic labels that describe the functional theme of this cluster.

Rules:
- Each label should be 1-3 words maximum
- Use specific English noun phrases (e.g. "appointment", "office visit", "diagnosis")
- No camelCase, no abbreviations with parentheses, no explanations
- Return ONLY a numbered list, one label per line

Example format:
1. appointment
2. office visit
3. diagnosis
4. prescription
5. vaccination
"""


def get_llm_strategy_a_labels(cluster: dict, model: str,
                               top_n: int = TOP_N_LABELS) -> dict:
    """
    Generate cluster labels using Strategy A (representative requirement texts).

    Retries with progressively fewer requirements on timeout.

    Returns:
        {'display': ['office visit', ...], 'kappa': ['visit', ...]}
    """
    max_reqs = MAX_REQS_PER_CLUSTER

    for attempt in range(1, OLLAMA_RETRIES + 2):  # +2: first try + N retries
        texts  = _select_central_reqs(cluster, max_reqs)
        prompt = _build_prompt(texts, top_n)
        n_reqs = len(texts)

        logger.debug(
            f"[Strategy A | {model}] attempt {attempt}: "
            f"sending {n_reqs} requirements ({len(prompt)} chars)"
        )

        response = query_ollama(model, prompt, _attempt=attempt)

        if response == "__TIMEOUT__":
            # Halve the number of requirements and retry
            max_reqs = max(3, n_reqs // 2)
            logger.warning(
                f"[Strategy A | {model}] Timeout with {n_reqs} reqs. "
                f"Retrying with {max_reqs} reqs..."
            )
            continue

        if not response:
            logger.warning(f"[Strategy A | {model}] Empty response (attempt {attempt}).")
            return {"display": [], "kappa": []}

        display, kappa = parse_llm_response(response, top_n)
        logger.debug(f"[Strategy A | {model}] display={display[:3]} kappa={kappa[:3]}")
        return {"display": display, "kappa": kappa}

    logger.error(f"[Strategy A | {model}] All {OLLAMA_RETRIES + 1} attempts failed.")
    return {"display": [], "kappa": []}
