# =============================================================================
# labeling/llm/strategy_b.py
# LLM Strategy B: Feed TOP TF-IDF KEYWORDS to the LLM.
#
# Strategy B is inherently fast (keywords only, ~50 chars of input) so
# timeouts are rare.  Retry logic is included for robustness.
# =============================================================================

import logging
import sys
import os

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
from config import TOP_N_LABELS, TOP_N_KEYWORDS, OLLAMA_RETRIES
from labeling.llm.ollama_client import query_ollama
from labeling.llm._label_clean import parse_llm_response
from labeling.traditional.fpw_labeler import get_fpw_labels

logger = logging.getLogger(__name__)


def _build_prompt(keywords: list[str], top_n: int) -> str:
    kw_str = ", ".join(keywords)
    return f"""You are an expert in software requirements engineering.
The following keywords were extracted from a cluster of related software requirements:

Keywords: {kw_str}

Generate exactly {top_n} short topic labels that best describe the theme of this cluster.

Rules:
- Each label should be 1-3 words maximum
- Use specific English noun phrases (e.g. "appointment", "office visit", "diagnosis")
- No camelCase, no abbreviations with parentheses, no explanations
- Return ONLY a numbered list, one label per line

Example format:
1. appointment
2. office visit
3. diagnosis
"""


def get_llm_strategy_b_labels(cluster: dict, all_clusters: dict,
                               model: str, top_n: int = TOP_N_LABELS,
                               n_keywords: int = TOP_N_KEYWORDS) -> dict:
    """
    Returns:
        {'display': ['office visit', ...], 'kappa': ['visit', ...]}
    """
    keywords = get_fpw_labels(cluster, all_clusters, top_n=n_keywords)
    if not keywords:
        logger.warning(f"[Strategy B | {model}] No keywords extracted.")
        return {"display": [], "kappa": []}

    prompt = _build_prompt(keywords, top_n)

    for attempt in range(1, OLLAMA_RETRIES + 2):
        response = query_ollama(model, prompt, _attempt=attempt)

        if response == "__TIMEOUT__":
            logger.warning(
                f"[Strategy B | {model}] Timeout (attempt {attempt}). "
                f"Retrying..."
            )
            continue

        if not response:
            logger.warning(f"[Strategy B | {model}] Empty response (attempt {attempt}).")
            return {"display": [], "kappa": []}

        display, kappa = parse_llm_response(response, top_n)
        logger.debug(f"[Strategy B | {model}] kw={keywords[:3]} display={display[:3]} kappa={kappa[:3]}")
        return {"display": display, "kappa": kappa}

    logger.error(f"[Strategy B | {model}] All {OLLAMA_RETRIES + 1} attempts failed.")
    return {"display": [], "kappa": []}
