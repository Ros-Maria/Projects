# =============================================================================
# labeling/llm/ollama_client.py
# Wrapper for Ollama local LLM API.
# No API key needed. Runs fully offline via http://localhost:11434
# =============================================================================

import requests
import logging
import sys
import os

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
from config import OLLAMA_URL, OLLAMA_TIMEOUT, OLLAMA_RETRIES

logger = logging.getLogger(__name__)


def query_ollama(model: str, prompt: str,
                 timeout: int = None, _attempt: int = 1) -> str:
    """
    Send a prompt to a local Ollama model and return the response text.

    On timeout, retries up to OLLAMA_RETRIES times. Callers can pass a
    custom timeout (strategy_a uses this to reduce timeout on retries
    rather than waiting the full period again).

    Args:
        model:    model name, e.g. "llama3.2" or "mistral"
        prompt:   full prompt string
        timeout:  seconds to wait (defaults to OLLAMA_TIMEOUT from config)
        _attempt: internal retry counter (do not set externally)

    Returns:
        Response text, or empty string on failure.
    """
    timeout = timeout or OLLAMA_TIMEOUT
    url     = f"{OLLAMA_URL}/api/generate"
    payload = {"model": model, "prompt": prompt, "stream": False}

    try:
        response = requests.post(url, json=payload, timeout=timeout)
        response.raise_for_status()
        return response.json().get("response", "").strip()

    except requests.exceptions.ConnectionError:
        logger.error(
            f"Cannot connect to Ollama at {OLLAMA_URL}. "
            "Make sure Ollama is running: run 'ollama serve' in a terminal."
        )
        return ""

    except requests.exceptions.Timeout:
        if _attempt <= OLLAMA_RETRIES:
            logger.warning(
                f"Ollama timeout after {timeout}s for model '{model}' "
                f"(attempt {_attempt}/{OLLAMA_RETRIES + 1}). "
                f"Retrying with a shorter prompt..."
            )
            # Signal to caller that a retry is needed with fewer requirements.
            # We use a sentinel so strategy_a can rebuild a shorter prompt.
            return "__TIMEOUT__"
        logger.error(
            f"Ollama timed out after {OLLAMA_RETRIES + 1} attempts for '{model}'. "
            f"Try increasing OLLAMA_TIMEOUT in config.py, or reducing "
            f"MAX_REQS_PER_CLUSTER."
        )
        return ""

    except Exception as e:
        logger.error(f"Ollama error for model '{model}': {e}")
        return ""


def check_model_available(model: str) -> bool:
    try:
        response = requests.get(f"{OLLAMA_URL}/api/tags", timeout=10)
        response.raise_for_status()
        models = [m["name"].split(":")[0] for m in response.json().get("models", [])]
        return model.split(":")[0] in models
    except Exception:
        return False


def list_available_models() -> list[str]:
    try:
        response = requests.get(f"{OLLAMA_URL}/api/tags", timeout=10)
        response.raise_for_status()
        return [m["name"] for m in response.json().get("models", [])]
    except Exception:
        return []
