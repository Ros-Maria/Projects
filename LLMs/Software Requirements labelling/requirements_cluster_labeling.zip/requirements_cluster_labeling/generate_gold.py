"""
generate_gold.py
================
Generates gold standard JSON from the latest pipeline label output.

Gold labels are always SINGLE KEYWORDS so kappa comparison is fair
between traditional methods (which produce keywords) and LLM methods
(which produce phrases whose head nouns are used for kappa).

When picking gold from LLM output, we use the 'kappa' keyword list
(head nouns), not the 'display' phrase list.

Run immediately after main.py — never reuse gold from a previous run
with a different cluster count.
"""
import os
import sys
import json
import argparse
import logging
from datetime import datetime

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from config import GOLD_DIR, RESULTS_TABLES, DATASETS

logging.basicConfig(level=logging.INFO, format="%(levelname)s  %(message)s")
logger = logging.getLogger(__name__)


def load_latest_labels(dataset_name: str) -> dict | None:
    pattern = f"{dataset_name}_labels_"
    try:
        files = [
            f for f in os.listdir(RESULTS_TABLES)
            if f.startswith(pattern) and f.endswith(".json")
        ]
    except FileNotFoundError:
        return None
    if not files:
        return None
    latest = sorted(files)[-1]
    logger.info(f"Loading labels from: {latest}")
    with open(os.path.join(RESULTS_TABLES, latest), "r", encoding="utf-8") as f:
        data = json.load(f)
    cluster_keys = [k for k in data.keys() if not k.startswith("_")]
    logger.info(f"Found {len(cluster_keys)} clusters: {sorted(cluster_keys)}")
    return data


def _get_kappa_labels(label_data) -> list:
    """
    Extract the keyword list from a method's label data.
    LLM methods store {'display': [...], 'kappa': [...]}.
    Traditional methods store a plain list.
    """
    if isinstance(label_data, dict):
        return label_data.get("kappa", [])
    return label_data


def pick_gold_labels(method_dict: dict) -> list:
    """
    Pick the best available keyword labels as gold.
    Priority: mistral_B > mistral_A > llama3.2_B > llama3.2_A > fpw > chi2 > tf
    Always uses kappa keywords (single words), not display phrases.
    """
    priority = ["mistral_B", "mistral_A", "llama3.2_B", "llama3.2_A",
                "fpw", "chi2", "tf"]
    for method in priority:
        if method not in method_dict:
            continue
        labels = _get_kappa_labels(method_dict[method])
        valid  = [l for l in labels if l and l != "[skipped]"]
        if valid:
            logger.info(f"  Using '{method}' kappa keywords as gold")
            return valid
    # Fallback
    for method, data in method_dict.items():
        labels = _get_kappa_labels(data)
        valid  = [l for l in labels if l and l != "[skipped]"]
        if valid:
            logger.info(f"  Using '{method}' as gold (fallback)")
            return valid
    return []


def generate_gold_from_labels(dataset_name: str) -> bool:
    all_labels = load_latest_labels(dataset_name)
    if all_labels is None:
        logger.error(f"No label files for '{dataset_name}'. Run main.py first.")
        return False

    gold = {}
    logger.info(f"\nBuilding gold standard for '{dataset_name}':")
    for cluster_key in sorted(all_labels.keys()):
        if cluster_key.startswith("_"):
            continue
        chosen = pick_gold_labels(all_labels[cluster_key])
        gold[cluster_key] = chosen
        logger.info(f"  {cluster_key}: {chosen[:3]}...")

    if not gold:
        logger.error("No clusters found — aborting.")
        return False

    os.makedirs(GOLD_DIR, exist_ok=True)
    out_path = os.path.join(GOLD_DIR, f"{dataset_name}_gold.json")
    gold_data = {
        "_notes": {
            "dataset":      dataset_name,
            "generated_by": "generate_gold.py",
            "generated_at": datetime.now().isoformat(),
            "n_clusters":   len(gold),
            "label_type":   "single keywords (kappa head nouns for LLM, unstemmed tokens for traditional)",
            "important":    "Re-run generate_gold.py after every main.py run to keep cluster count in sync.",
        }
    }
    gold_data.update(gold)

    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(gold_data, f, indent=2)

    logger.info(f"\nSaved: {out_path}  ({len(gold)} clusters)")
    return True


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--dataset", choices=list(DATASETS.keys()))
    args = parser.parse_args()

    targets = [args.dataset] if args.dataset else list(DATASETS.keys())
    success = 0
    for dataset in targets:
        logger.info(f"\n{'='*50}\nDataset: {dataset}\n{'='*50}")
        if generate_gold_from_labels(dataset):
            success += 1
        else:
            logger.warning(f"Skipped {dataset}")

    logger.info(f"\nDone. {success}/{len(targets)} gold standards generated.")


if __name__ == "__main__":
    main()
